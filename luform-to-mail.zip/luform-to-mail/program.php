<?php

require 'connect.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Check that the form was submitted
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    die("Invalid request.");
}

// Collect form data
$fullname = trim($_POST['fullname']);
$email = trim($_POST['email']);
$phone = trim($_POST['phone']);
$age = trim($_POST['age']);
$country = trim($_POST['country']);
$city = trim($_POST['city']);
$career_goal = trim($_POST['career_goal']);

// Basic validation
if (
    empty($fullname) ||
    empty($email) ||
    empty($phone) ||
    empty($age) ||
    empty($country) ||
    empty($city) ||
    empty($career_goal)
) {
    die("Please fill in all required fields.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Invalid email address.");
}

// Check if email already exists
$check = $conn->prepare("SELECT id FROM registrations WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    header("Location: already_register.php");
    exit();
}

$check->close();

// Prepare SQL statement
$sql = "INSERT INTO registrations
(fullname, email, phone, age, country, city, career_goal)
VALUES (?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

$stmt->bind_param(
    "sssssss",
    $fullname,
    $email,
    $phone,
    $age,
    $country,
    $city,
    $career_goal
);

// Only continue if database insertion succeeds
if ($stmt->execute()) {

    $mail = new PHPMailer(true);

    try {

        $mail->isSMTP();

        $mail->Host = 'smtp.gmail.com';

        $mail->SMTPAuth = true;

        $mail->Username = 'talabimicheal09@gmail.com';

        $mail->Password = 'tpurfnctjwcujsck';

        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;

        $mail->Port = 587;

        // Sender
        $mail->setFrom(
            'talabimicheal09@gmail.com',
            'Masterclass Registration'
        );

        // Receive notification
        $mail->addAddress('talabimicheal09@gmail.com');

        $mail->isHTML(true);

        $mail->Subject = 'New Masterclass Registration';

        $mail->Body = "
        <h2>New Registration Received</h2>

        <p><strong>Full Name:</strong> $fullname</p>

        <p><strong>Email:</strong> $email</p>

        <p><strong>Phone:</strong> $phone</p>

        <p><strong>Age:</strong> $age</p>

        <p><strong>Country:</strong> $country</p>

        <p><strong>City:</strong> $city</p>

        <p><strong>Career Goal:</strong> $career_goal</p>
        ";

        $mail->send();

        // Redirect after everything succeeds
        header("Location: thankyou.php");
        exit();

    } catch (Exception $e) {

        // echo "<h2>Registration saved successfully.</h2>";
        // echo "<p>However, the email notification could not be sent.</p>";
        // echo "<p>Error: " . $mail->ErrorInfo . "</p>";

        header("Location: thankyou.php");
        exit();
    }

} else {

    echo "<h2>Registration Failed</h2>";
    echo "<p>Database Error: " . $stmt->error . "</p>";
}


// Close connections
$stmt->close();
$conn->close();

?>