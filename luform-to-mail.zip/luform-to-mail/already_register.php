<!DOCTYPE html>
<html>
<head>
    <title>Already Registered</title>
    <style>
        body{
            font-family:Arial, sans-serif;
            background:#f4f4f4;
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
            margin:0;
        }

        .card{
            background:#fff;
            padding:40px;
            border-radius:10px;
            box-shadow:0 4px 10px rgba(0,0,0,.15);
            text-align:center;
            width:450px;
        }

        h2{
            color:#dc3545;
        }

        a{
            display:inline-block;
            margin-top:20px;
            background:#007bff;
            color:#fff;
            padding:12px 20px;
            text-decoration:none;
            border-radius:5px;
        }

        a:hover{
            background:#0056b3;
        }
    </style>
</head>
<body>

<div class="card">
    <h2>Registration Already Submitted</h2>

    <p>
        Our records show that this email address has already been used to register
        for the masterclass.
    </p>

    <a href="index.html">Return to Registration Form</a>
</div>

</body>
</html>