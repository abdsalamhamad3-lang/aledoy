CREATE TABLE registrations(
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    age VARCHAR(20),
    country VARCHAR(100),
    city VARCHAR(100),
    career_goal VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);