<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Registration Successful</title>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial, Helvetica, sans-serif;
}

body{

display:flex;
justify-content:center;
align-items:center;
height:100vh;
background:#f5f7fb;

}

.card{

background:white;
padding:50px;
border-radius:15px;
box-shadow:0 10px 25px rgba(0,0,0,.1);
text-align:center;
max-width:500px;
width:90%;

}

.success{

font-size:70px;
color:#28a745;
margin-bottom:20px;

}

h1{

color:#0d47a1;
margin-bottom:15px;

}

p{

color:#555;
font-size:17px;
line-height:1.7;

}

a{

display:inline-block;
margin-top:30px;
padding:14px 30px;
background:#0d47a1;
color:white;
text-decoration:none;
border-radius:8px;
transition:.3s;

}

a:hover{

background:#1565c0;

}

</style>

</head>

<body>

<div class="card">

<div class="success">✔</div>

<h1>Registration Successful!</h1>

<p>

Thank you for registering for our Masterclass.

Your registration has been received successfully, and we've also sent a confirmation to our team.

We look forward to seeing you!

</p>

<a href="index.html">Return Home</a>

</div>

</body>

</html>